#pragma once

#include <stdint.h>
#include "stm32f7xx_hal.h"
#include "stm32f7xx_hal_sai.h"
#include "stm32f746xx.h"
#include <math.h>

#define CODEC_ADDR (uint16_t)0x34
#define CODEC_ID 0x8994

#define AUDIO_FREQUENCY_48K (uint32_t)48000U
#define AUDIO_FREQUENCY_44K (uint32_t)44100U
#define AUDIO_FREQUENCY_32K (uint32_t)32000U
#define AUDIO_FREQUENCY_24K (uint32_t)24000U
#define AUDIO_FREQUENCY_16K (uint32_t)16000U
#define AUDIO_FREQUENCY_12K (uint32_t)12000U
#define AUDIO_FREQUENCY_8K  (uint32_t)8000U

extern int16_t* R1;
extern int16_t* R2;
extern int16_t* T1;
extern int16_t* T2;
extern uint8_t SX_R, SX_T;


uint8_t codec_init(I2C_HandleTypeDef* hi2c3,  uint32_t audio_freq);

void linear_copy(int16_t* src, int16_t* dest, uint16_t length);
