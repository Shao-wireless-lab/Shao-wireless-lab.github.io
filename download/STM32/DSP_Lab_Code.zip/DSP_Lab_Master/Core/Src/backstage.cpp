#include <backstage.hpp>

int16_t* R1;
int16_t* R2;
int16_t* T1;
int16_t* T2;
uint8_t SX_R, SX_T;

void PUT_YOUR_LAB_CODE_HERE(int16_t input_left, int16_t input_right, int16_t& output_left, int16_t& output_right);

uint16_t codec_read_reg(I2C_HandleTypeDef* h_i2c, uint16_t reg_addr) {

  uint16_t tmp = 0, data = 0;

  HAL_StatusTypeDef ret = HAL_I2C_Mem_Read(h_i2c, CODEC_ADDR, reg_addr, 2,
                                                       (uint8_t*)&tmp, 2, 1000);

  /// prevents unused variable warning
  (void)ret;

  /// flips the endianness of the data to match the microcontroller
  data = ((tmp>>8)) & 0x00ff;
  data |= ((tmp<<8)) & 0xff00;

  return data;

}

uint8_t codec_write_reg(I2C_HandleTypeDef* h_i2c, uint16_t reg_addr,
                                                                uint16_t data) {

  /// flips the endianness of the data to match the codec
  uint16_t tmp = ((data>>8)) & 0x00ff;
  tmp |= ((data<<8)) & 0xff00;

  /// uint16_t tmp = data;

  HAL_StatusTypeDef ret = HAL_I2C_Mem_Write(h_i2c, CODEC_ADDR, reg_addr,
                      (uint16_t)2, (uint8_t*)&tmp, (uint16_t)2, (uint32_t)1000);

  return (uint8_t)ret;

}

uint8_t codec_init(I2C_HandleTypeDef* hi2c3, uint32_t audio_freq) {

  /// check to make sure the microcontroller can talk to the codec
  uint16_t codec_id = codec_read_reg(hi2c3, 0x0000);
  if(codec_id != CODEC_ID) {
    return 1;
  }

  uint8_t ret = 0;

  /// reset the codec to the default state
  codec_write_reg(hi2c3, 0x0000, 0x0000);

  /// wm8994 errata work arounds lifted from ST's driver, but like, I cant
  /// find the errata so idk what this is doing or fixing.
  ret += codec_write_reg(hi2c3, 0x0102, 0x0003);
  ret += codec_write_reg(hi2c3, 0x0817, 0x0000);
  ret += codec_write_reg(hi2c3, 0x0102, 0x0000);

/// Chip Configuration /////////////////////////////////////////////////////////

  /// Enable VMID buffer, enable start up current generator
  ret += codec_write_reg(hi2c3, 0x0039, 0x006C);

  /// Enable the normal bias current generator, select normal VMID divider
  ret += codec_write_reg(hi2c3, 0x0001, 0x0003);

  /// short delay to let the bias generator stabilize
  HAL_Delay(50);

  /// sets protocol to I2S and word length to 16-bit
  ret += codec_write_reg(hi2c3, 0x0300, 0x4010);

  /// ensure AIF1 is in slave mode and operating in normal mode
  ret += codec_write_reg(hi2c3, 0x0302, 0x0000);

  /// enable AIF1 processing clock, select AIF1CLK as SYSCLK
  ret += codec_write_reg(hi2c3, 0x0208, 0x000A);

  /// turn off oversampling on DAC and ADC
  ret += codec_write_reg(hi2c3, 0x0620, 0x0000);

  /// set the clock ratios for the various sample rates
  switch(audio_freq) {
    case AUDIO_FREQUENCY_8K:
      ret += codec_write_reg(hi2c3, 0x0210, 0x0003);
      break;
    case AUDIO_FREQUENCY_12K:
      ret += codec_write_reg(hi2c3, 0x0210, 0x0023);
      break;
    case AUDIO_FREQUENCY_16K:
      ret += codec_write_reg(hi2c3, 0x0210, 0x0033);
      break;
    case AUDIO_FREQUENCY_24K:
      ret += codec_write_reg(hi2c3, 0x0210, 0x0053);
      break;
    case AUDIO_FREQUENCY_32K:
      ret += codec_write_reg(hi2c3, 0x0210, 0x0063);
      break;
    case AUDIO_FREQUENCY_44K:
      ret += codec_write_reg(hi2c3, 0x0210, 0x0073);
      break;
    case AUDIO_FREQUENCY_48K:
    default:
      ret += codec_write_reg(hi2c3, 0x0210, 0x0083);
      break;
  }

////////////////////////////////////////////////////////////////////////////////

/// Input Configuration ////////////////////////////////////////////////////////

  /// Connects IN1LN & IN1RN to their respective PGA and references them to VMID
  ret += codec_write_reg(hi2c3, 0x0028, 0x0011);

  /// Unmute IN1L and set volume to 0dB
  ret += codec_write_reg(hi2c3, 0x0018, 0x000B);

  /// Unmute IN1R and set volume to 0dB
  ret += codec_write_reg(hi2c3, 0x001A, 0x000B);

  /// Unmute IN1L to MIXINL path
  ret += codec_write_reg(hi2c3, 0x0029, 0x0020);

  /// Unmute IN1R to MIXINR path
  ret += codec_write_reg(hi2c3, 0x002A, 0x0020);

  /// enable thermal shutdown, enable left and right input mixer, enable IN1L
  /// and IN1R PGAs
  ret += codec_write_reg(hi2c3, 0x0002, 0x6350);

  /// Enable ADCL and ADCR, route ADCL to AIF1 Timeslot 0 Left, route ADCR to
  /// AIF1 Timeslot 0 Right
  ret += codec_write_reg(hi2c3, 0x0004, 0x0303);

  /// enable ADCL to AIF1 route
  ret += codec_write_reg(hi2c3, 0x0606, 0x0002);

  /// enable ADCR to AIF1 route
  ret += codec_write_reg(hi2c3, 0x0607, 0x0002);

  /// enable a built in HPF in AIF1 to remove DC offsets
  ret += codec_write_reg(hi2c3, 0x0410, 0x1800);

  /// set the volume of AIF1L to ADCL path to 0db
  ret += codec_write_reg(hi2c3, 0x0400, 0x00C0);

  /// set the volume of AIF1R to ADCR path to 0db
  ret += codec_write_reg(hi2c3, 0x0401, 0x00C0);

  /* GPIO1 pin configuration GP1_DIR = output, GP1_FN = AIF1 DRC1 signal detect */
  ret += codec_write_reg(hi2c3, 0x0700, 0x000D);

////////////////////////////////////////////////////////////////////////////////

/// Output Configuration ///////////////////////////////////////////////////////

  /// enable DAC1L and DAC1R, enable AIF1 to DAC1 pathway
  ret += codec_write_reg(hi2c3, 0x0005, 0x0303);

  /// select AIF1L to DAC1L pathway
  ret += codec_write_reg(hi2c3, 0x0601, 0x0001);

  /// select AIF1R to DAC1R pathway
  ret += codec_write_reg(hi2c3, 0x0602, 0x0001);

  /// Route DAC1L to HPOUT1LVOL
  ret += codec_write_reg(hi2c3, 0x002D, 0x0100);

  /// Route DAC1R to HPOUT1RVOL
  ret += codec_write_reg(hi2c3, 0x002E, 0x0100);

  /// set charge pump to class W
  ret += codec_write_reg(hi2c3, 0x0051, 0x0005);

  /// Enable the charge pump
  ret += codec_write_reg(hi2c3, 0x004C, 0x9F25);

  /// Short delay to let the charge pump stabilize
  HAL_Delay(50);

  /// unmute HPOUT1LVOL and set volume to 0dB
  ret += codec_write_reg(hi2c3, 0x001C, 0x0179);

  /// unmute HPOUT1RVOL and set volume to 0dB
  ret += codec_write_reg(hi2c3, 0x001D, 0x0179);

  /// enable input stages for HPOUT1L and HPOUT1R
  ret += codec_write_reg(hi2c3, 0x0001, 0x0303);

  /// Datasheet recommended delay**
  HAL_Delay(20);

  /// enable intermediate stage of HPOUT1L and HPOUT1R
  ret += codec_write_reg(hi2c3, 0x0060, 0x0022);

  /// enable the DC servo
  ret += codec_write_reg(hi2c3, 0x0054, 0x0033);

  /// give the DC servo time to run
  HAL_Delay(250);

  /// enable the output stage of HPOUT1L and HPOUT1R, remove all clamps
  ret += codec_write_reg(hi2c3, 0x0060, 0x00EE);

  /// remove the final software mute on AIF1 to DAC1 pathway
  ret += codec_write_reg(hi2c3, 0x0420, 0x0010);

  /// unmute DAC1L and set volume to 0dB
  ret += codec_write_reg(hi2c3, 0x0610, 0x00C0);

  /// unmute DAC1R and set volume to 0dB
  ret += codec_write_reg(hi2c3, 0x0611, 0x00C0);

////////////////////////////////////////////////////////////////////////////////

  /// select MCLK1 as clock source and enable AIF1CLK
  ret += codec_write_reg(hi2c3, 0x0200, 0x0001);

  return ret;
}

void linear_copy(int16_t* src, int16_t* dest, uint16_t length) {

  int16_t l, r;

  for(uint16_t i = 0; i < length; i += 2) {

    l = *(src + i);
    r = *(src + i + 1);

   PUT_YOUR_LAB_CODE_HERE(*(src + i), *(src + i + 1), l, r);

    *(dest + i) = l;
    *(dest + i + 1) = r;

  }

}

void HAL_SAI_RxCpltCallback(SAI_HandleTypeDef *hsai) {

  (void)hsai;

  SX_R = 0;

}

void HAL_SAI_TxCpltCallback(SAI_HandleTypeDef *hsai) {

  (void)hsai;

  SX_T = 0;

}
